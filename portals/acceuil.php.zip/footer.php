 <footer class="main-footer">
    <div class="pull-right d-none d-sm-inline-block">
      <b>Version</b> 1.0
    </div>Copyright &copy; 2020 <a href="#">afreekaplay</a>. All Rights Reserved.
  </footer>
