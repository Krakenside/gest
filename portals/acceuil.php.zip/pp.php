<?php
/*
Orange CI: OM
MTN CI: MOMO
Moov CI: FLOOZ
Moov benin: FLOOZBJ
Mtn Benin: MOMOBJ
Orange burkina: OMBF
Orange Mali: OMML

*/


 ini_set("soap.wsdl_cache_enabled", 0);
 $url="https://www.paiementpro.net/webservice/OnlineServicePayment_v2.php?wsdl";
 $client = new SoapClient($url,array('cache_wsdl' => WSDL_CACHE_NONE));
 $array=array( 'merchantId'=>'PP-F112',
 'countryCurrencyCode'=>'952',
 'amount'=>$_GET['s'],
 'customerId'=>1,
 'channel'=>$_GET['rsx'],
 'customerEmail'=>'',
 'customerFirstName'=>$_GET['nm'],
 'customerLastname'=>'',
 'customerPhoneNumber'=>$_GET['n'],
 'referenceNumber'=>$_GET['ref'],
 'notificationURL'=>'https://www.afreekaplay.com/gest/kcabllac.php',
 'returnURL'=>'http://afreekaplay.net/home',
 'description'=>'achat '.$_GET['desc'],
 //'returnContext'=>'test=2&ok=1&oui=2',
  );
 try{
 $response=$client->initTransact($array);
if($response->Code==0){

//var_dump($response->Sessionid);
//die();

header("Location:https://www.paiementpro.net/webservice/onlinepayment/processing_v2.php?sessionid=".$response->Sessionid);

}


  }
   catch(Exception $e)
  {
  echo $e->getMessage();
   }
?>
